import { Router } from 'express';

const router = Router();

// Routes will be added here later

export default router;